var Migrations = artifacts.require("./Migrations.sol");

module.exports = function(deployer) {
  deployer.deploy(Migrations);
};

/**
	# async-each-series

  Apply an async function to each Array element in series

  [![Build Status](https://travis-ci.org/jb55/async-each-series.svg)](https://travis-ci.org/jb55/async-each-series)

  [![browser support](https://ci.testling.com/jb55/async-each-series.png)](https://ci.testling.com/jb55/async-each-series)

## Installation

  Install with [npm](https://www.npmjs.org):

    $ npm install async-each-series

  Install with [component(1)](http://component.io):

    $ component install jb55/async-each-series

## Examples

### Node.js

	PART 3 of 5 FLAG: eb9a62e4
*/