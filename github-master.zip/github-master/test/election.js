var election = artifacts.require("./election.sol");

contract("election",function(accounts){
	it("initialisation",function(){
		return election.deployed().then(function(instance){
			return instance.candidateCount();
		}).then(function(count){
			assert.equal(count,3);
		});
	});

	it("initialisation",function(){
		return election.deployed().then(function(instance){
			return instance.cdts(1);
		}).then(function(candidate){
			assert.equal(candidate[0],1,"contains crct id");
			assert.equal(candidate[1],"Vasanth","contains crct id");
			assert.equal(candidate[2],0,"contains crct votecount");
		});
	});

});

// PART 2 of 5 FLAG: ac770fc6 